﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSP
{
    public class ModifiedRectangle
    {
        public virtual int Width { get; set; }
        public virtual int Height { get; set; }

        public ModifiedRectangle()
        {

        }

        public ModifiedRectangle(int width, int height)
        {
            Width = width;
            Height = height;
        }

        public override string ToString()
        {
            return $"{nameof(Width)}: {Width}, {nameof(Height)}: {Height}";
        }
    }

    public class ModifiedSquare : ModifiedRectangle
    {
        public override int Width 
        {
            set { base.Width = base.Height = value; }
        }

        public override int Height
        {
            set { base.Width = base.Height = value; }
        }
    }

}
