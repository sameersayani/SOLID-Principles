﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP
{
    //High-level modules should not depend on low-level modules. Both should depend on abstractions.
    //Abstractions should not depend upon details.Details should depend upon abstractions.

    public interface IMessage
    {
        string SendMessage();
    }

    public class SendEmail : IMessage
    {
        public string SendMessage()
        {
            return "Mail Sent...";
        }
    }
    public class SendSms : IMessage
    {
        public string SendMessage()
        {
            return "Sms Sent...";
        }
    }

    public class User
    {
        public string From { get; set; }
        public string To { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }

        private IMessage message;
        public User(IMessage _message)
        {
            message = _message;
        }

        public void Send()
        {
            switch (message.ToString())
            {
                case "DIP.SendEmail":
                    Console.WriteLine("Mail Sent...");
                    break;
                case "DIP.SendSms":
                    Console.WriteLine("Sms Sent...");
                    break;
            }
        }
    }

}
