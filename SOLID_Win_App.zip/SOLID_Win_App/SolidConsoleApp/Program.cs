﻿using DIP;
using ISP;
using LSP;
using OCP;
using SRP;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            #region 1. SRP - Single Responsibility Principle

            var j = new Journal();
            j.AddEntry("Today, I learned SOLID Priciples");
            j.AddEntry("I also implemented a POC");
            Console.WriteLine(j);

            var p = new Persistence();
            var filename = @"c:\temp\journal.txt";
            p.SaveToFile(j, filename, true);
            Process.Start(filename);

            #endregion

            #region 2. OCP - Open Closed Principle

            // While violating OCP
            var shirt = new Product("Shirt", Color.White, Size.Medium);
            var tshirt = new Product("T-Shirt", Color.White, Size.Medium);
            var trouser = new Product("Trouser", Color.Black, Size.Large);
            var blazer = new Product("Blazer", Color.Black, Size.Large);

            Product[] products = { shirt, tshirt, trouser, blazer };

            var pf = new ProductFilter();
            Console.WriteLine("Black products (before):");
            foreach (var prd in pf.FilterByColor(products, Color.Black))
                Console.WriteLine($" - {prd.Name} is " + Color.Black);

            // Console.ReadKey();

            // After following OCP
            var bf = new BetterFilter();
            Console.WriteLine("Black products (new):");
            foreach (var p1 in bf.Filter(products, new ColorSpecification(Color.Black)))
                Console.WriteLine($" - {p1.Name} is " + Color.Black);

            Console.WriteLine("Large products : ");
            foreach (var p2 in bf.Filter(products, new SizeSpecification(Size.Large)))
                Console.WriteLine($" - {p2.Name} is " + Size.Large);

            Console.WriteLine("Medium white items : ");
            foreach (var p3 in bf.Filter(products,
              new AndSpecification<Product>(new ColorSpecification(Color.White)
              , new SizeSpecification(Size.Medium)))
            )
            {
                Console.WriteLine($" - {p3.Name} is Medium and White");
            }

            // Console.ReadKey();
            #endregion

            #region 3. LSP - Liskov Substitution Principle

            int Area(Rectangle r) => r.Width * r.Height;

            Rectangle rc = new Rectangle(2, 3);
            Console.WriteLine($"{rc} has area {Area(rc)}");

            Square sq = new Square();
            sq.Width = 4;
            Console.WriteLine($"{sq} has area {Area(sq)}");

            //Till now, everything looks fine, but what if I do the following...
            //As inheritance, Square is a Recctanlge, isn't it..

            Rectangle sq1 = new Square();
            sq1.Width = 4;
            Console.WriteLine($"{sq1} has area {Area(sq1)}");

            //Above, violates LSP

            //In order to fix this, we need to make some changes...

            int Area2(ModifiedRectangle mr) => mr.Width * mr.Height;

            ModifiedRectangle rct = new ModifiedRectangle(2, 3);
            Console.WriteLine($"{rct} has area {Area2(rct)}");

            //LSP says, should be able to substitute a base type for a subtype
            /*Square*/
            ModifiedRectangle sqr = new ModifiedSquare();
            sqr.Width = 4;
            Console.WriteLine($"{sqr} has area {Area2(sqr)}");

            // Console.ReadKey();

            #endregion

            #region 4. ISP - Interface Segregation Principle
            Document doc = new Document();
            IPrinter printer = new Printer();
            IScanner scanner = new Scanner();
            IFax fax = new Faxer();
            Photocopier printscan = new Photocopier(printer, scanner);
            printscan.Print(doc);
            printscan.Scan(doc);
            MultiFunctionMachine multiFunctionPrinter = new MultiFunctionMachine(printer, scanner, fax);
            multiFunctionPrinter.Print(doc);
            multiFunctionPrinter.Scan(doc);
            multiFunctionPrinter.Fax(doc); // decorator

            Console.ReadKey();
            #endregion

            #region 5. DIP - Dependency Inversion Principle

            //Here we have delegated the dependent object creation making the user object to decide which mode of message to use...
            var user = new User(new SendEmail());
            user.Send();
            var user2 = new User(new SendSms());
            user2.Send();
            Console.ReadKey();
            #endregion

        }
    }
}
