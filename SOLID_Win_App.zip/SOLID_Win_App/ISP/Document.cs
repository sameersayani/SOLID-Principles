﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP
{
    public class Document
    {
    }

    //Here we have Just one interface having multiple methods
    public interface IMachine
    {
        void Print(Document d);
        void Fax(Document d);
        void Scan(Document d);
    }

    ////Inherting from this interface works fine for those clients who are having Muti function printer
    //public class MultiFunctionPrinter : IMachine
    //{
    //    public void Print(Document d)
    //    {
    //        Console.WriteLine("Print document");
    //    }

    //    public void Fax(Document d)
    //    {
    //        Console.WriteLine("Fax document");
    //    }

    //    public void Scan(Document d)
    //    {
    //        Console.WriteLine("Scan document");
    //    }
    //}

    //What if there are some clients which are having dot matrix old style printer
    //although they don't need Fax & Scan but still need to implement it as they are inherting from our interface
    //this violates ISP

    public class OldFashionedPrinter : IMachine
    {
        public void Print(Document d)
        {
            Console.WriteLine("Print document");
        }

        public void Fax(Document d)
        {
            throw new System.NotImplementedException();
        }

        public void Scan(Document d)
        {
            throw new System.NotImplementedException();
        }
    }

    //ISP says, instead of having one big interface, you should have smaller interfaces so that they are self contained
    public interface IPrinter
    {
        void Print(Document d);
    }

    public interface IScanner
    {
        void Scan(Document d);
    }

    public interface IFax
    {
        void Fax(Document d);
    }

    public class Printer : IPrinter
    {
        public void Print(Document d)
        {
            Console.WriteLine("Print document");
        }
    }
    public class Scanner : IScanner
    {
        public void Scan(Document d)
        {
            Console.WriteLine("Scanner document");
        }
    }
    public class Faxer : IFax
    {
        public void Fax(Document d)
        {
            Console.WriteLine("Fax document");
        }
    }
    public interface IMultiFunctionDevice : IPrinter, IScanner ,IFax
    {

    }

    public class Photocopier : IPrinter, IScanner
    {
        private IPrinter printer;
        private IScanner scanner;

        public Photocopier(IPrinter printer, IScanner scanner)
        {
            if (printer == null)
            {
                throw new ArgumentNullException(paramName: nameof(printer));
            }
            if (scanner == null)
            {
                throw new ArgumentNullException(paramName: nameof(scanner));
            }

            this.printer = printer;
            this.scanner = scanner;
        }
        public void Print(Document d)
        {
            printer.Print(d);
        }

        public void Scan(Document d)
        {
            scanner.Scan(d);
        }

    }

    public class MultiFunctionMachine : IMultiFunctionDevice
    {
        private IPrinter printer;
        private IScanner scanner;
        private IFax fax;

        public MultiFunctionMachine(IPrinter printer, IScanner scanner, IFax fax)
        {
            if (printer == null)
            {
                throw new ArgumentNullException(paramName: nameof(printer));
            }
            if (scanner == null)
            {
                throw new ArgumentNullException(paramName: nameof(scanner));
            }
            if (fax == null)
            {
                throw new ArgumentNullException(paramName: nameof(fax));
            }

            this.printer = printer;
            this.scanner = scanner;
            this.fax = fax;
        }

        public void Print(Document d)
        {
            printer.Print(d);
        }

        public void Scan(Document d)
        {
            scanner.Scan(d);
        }

        public void Fax(Document d)
        {
            fax.Fax(d);
        }

    }

}
